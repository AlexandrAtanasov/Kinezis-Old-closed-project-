<?php
	$db_name = "KP_Project";
	$db_user = "root";
	$db_user_pass = "";
	$db_host = "localhost";
?>