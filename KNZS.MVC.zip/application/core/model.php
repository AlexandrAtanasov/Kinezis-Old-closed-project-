<?php

    class Model 
    {
        public function get_data()
        {

        }
    }

?>