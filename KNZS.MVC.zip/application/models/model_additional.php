<?php

    class Model_Additional extends Model
    {
        public function get_data()
        {

            $routes = explode( '/', $_SERVER['REQUEST_URI'] );
            
            // get additional service's id
            if ( !empty($routes[3]) )
            {
                $service = $routes[3];
            };

            require_once __DIR__ . '/../core/std_incl.php';
            $pdo->query("SET CHARACTER SET 'utf8'");
            $result = $pdo->query("SELECT 
                `Title`, `Article`, `Img` 
                FROM `additional_services_list` WHERE id = " . $service  . ";");
            return $result;
        }
    }

?>